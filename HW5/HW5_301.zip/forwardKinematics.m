%%Karun Wiboolsirisak 58340500001
%%05/02/2018
%% Return Transformation Matrix and Visualization forward Kinematics
function [H, H_e, R_e, p_e] = forwardKinematics(q,DH_table,type)

% H := [4 x 4 x n] matrix
% H_e := [4 x 4] matrix
% R_e := [3 x 3] rotation matrix (not homogeneous matrix)
% p_e := column vector [3 x 1]

% q := [n x 1] column vector. can be either numeric or symbolic
% type := [n x 1] column vector. can only be numeric [0 or 1]
% DH_table := [n x 4] matrix. can be either numeric or symbolic

n = size(DH_table,1);

if ~strcmp(class(q),'sym')
    H = zeros(4,4,n);
else
    H = sym(zeros(4,4,n));
end


for i=1:n 
    if i == 1
        if type(i) == 1
            H(:,:,i) = DHTrans(q(i)+DH_table(i,1),DH_table(i,2),DH_table(i,3),DH_table(i,4));
        else 
            H(:,:,i) = DHTrans(DH_table(i,1),q(i)+DH_table(i,2),DH_table(i,3),DH_table(i,4));
        end
    else
        if type(i) == 1
            H(:,:,i) = H(:,:,i-1)*DHTrans(q(i)+DH_table(i,1),DH_table(i,2),DH_table(i,3),DH_table(i,4));
        else 
            H(:,:,i) = H(:,:,i-1)*DHTrans(DH_table(i,1),q(i)+DH_table(i,2),DH_table(i,3),DH_table(i,4));
        end
    end
end

H_e = H(:,:,end);
R_e = H_e(1:3,1:3);
p_e = H_e(1:3,4);

%% visualization 
% if ~strcmp(class(q),'sym')
%     axis equal
%     H_origin = [1 0 0 0;
%                 0 1 0 0;
%                 0 0 1 0;
%                 0 0 0 1];
% %     plotFrame(H_origin,0.5);
%     for i=1:n
%         if i == 1
%             plot3([0 H(1,4,i)],[0 H(2,4,i)],[0 H(3,4,i)]);
%         else
%             plot3([H(1,4,i-1) H(1,4,i)],[H(2,4,i-1) H(2,4,i)],[H(3,4,i-1) H(3,4,i)]);
%         end
% %         plotFrame(H(:,:,i),0.5);
%     end
% end