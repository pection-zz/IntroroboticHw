function trans_matrix = DHTrans(theta,d,a,alpha)
    trans_matrix = rot(theta,'z')*trans(d,'z')*trans(a,'x')*rot(alpha,'x');
end