%Karun Wiboolsirisak 58340500001
%29/01/2018
%This fuction is use to calculate basic homogenous transformation matrix from rotation
function Homo_matrix = rot(angle, axis)
    distance_matrix = zeros(3,1);
    zero_matrix = zeros(1,3);
    if axis == 'x'
        rotation_matrix = [1 0 0;
                           0 cos(angle) -sin(angle);
                           0 sin(angle) cos(angle)];
    elseif axis == 'y'
        rotation_matrix = [cos(angle) 0 sin(angle);
                           0 1 0;
                           -sin(angle) 0 cos(angle)];
    elseif axis == 'z'
        rotation_matrix = [cos(angle) -sin(angle) 0;
                           sin(angle) cos(angle) 0;
                           0 0 1];
    end
    Homo_matrix = [rotation_matrix distance_matrix;
                       zero_matrix 1];