%Karun Wiboolsirisak 58340500001
%29/01/2018
%This fuction is use to calculate basic homogenous transformation matrix from translations
function Homo_matrix = trans(distance, axis)
    rotation_matrix = eye(3);
    zero_matrix = zeros(1,3);
    if axis == 'x'
        distance_matrix = [distance;0;0];
    elseif axis == 'y'
        distance_matrix = [0;distance;0];
    elseif axis == 'z'
        distance_matrix = [0;0;distance];
    end
    Homo_matrix = [rotation_matrix distance_matrix;
                       zero_matrix 1;];
        